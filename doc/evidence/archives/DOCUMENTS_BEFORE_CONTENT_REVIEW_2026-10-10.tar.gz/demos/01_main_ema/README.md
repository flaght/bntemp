# 单品种主力 EMA 回测

全新EMA策略的成交验收使用空仓SimNow账户和新状态文件，不传接管参数。策略初始持仓0，预热后按真实EMA方向生成目标，成交回报更新策略归属。账户非空会拒绝空仓启动，不自动归给EMA。PF0907固定目标方案已撤回，相关文件和参数已删除。同步、回归及空仓命令见 [PF2026100908交接](../../doc/HANDOFF/live/HANDOFF_FRESH_EMA_2026-10-09.md)。

## 1. 使用方法

### 启动命令

从 pro 根目录、在已安装运行依赖的环境中执行，先设置 `export PYTHONPATH=.`。入口自动读取已有 `.env` 配置；没有配置数据路径时，可通过可选的 `--data-root` 或各文件路径参数指定。示例日期需与实际数据匹配。

**完整执行（显式设置常用参数）：**

```bash
python demos/01_main_ema/run_backtest.py \
  --product RB \
  --start-day 2026-01-05 --end-day 2026-05-26 \
  --fast 3 --slow 5 --quantity 1 \
  --bar-timestamp end --log-level WARNING --no-tearsheet
```

**默认执行（仅必填参数）：**

```bash
python demos/01_main_ema/run_backtest.py \
  --product RB \
  --start-day 2026-01-05 --end-day 2026-05-26
```

默认执行采用参数表中的默认值及已有数据路径配置；例如默认启用绩效图，不要求必须产生成交。

### 参数说明

“必选”表示启动时必须传入；“可选”表示有默认值或可由已有配置解析。数据路径虽然是可选参数，但运行前必须能解析到有效文件。

| 参数 | 必选 / 可选 | 含义与默认值 |
| --- | --- | --- |
| `--product` | 必选 | 品种代码，例如 RB、I、HC；一次运行一个品种 |
| `--start-day / --end-day` | 必选 | 回测日期范围 |
| `--fast / --slow` | 可选 | 快 / 慢 EMA 周期默认 3 / 5，按有效主力 Bar 计数，要求 0 < fast < slow |
| `--quantity` | 可选 | 多空目标手数绝对值，默认 1 |
| `--bar-timestamp` | 可选 | 默认 end，可选 start；start 由公共层转换为完成分钟 |
| `--bars-dir / --contract-struct / --fut-basic / --factors` | 可选 | 显式覆盖行情、角色表、条款及累计因子路径 |
| `--data-root` | 可选 | 按 role/ 和 kline/fut/ 布局推导路径 |
| `--factor-availability` | 可选 | 默认 aligned，使用已对齐资料；explicit 强制要求 available_ns。已有发布时间仍会校验 |
| `--max-notional` | 可选 | 单笔与持仓名义金额上限，默认 1,000,000 |
| `--require-fills` | 可选 | 要求至少一笔模拟成交，否则报错 |
| `--no-tearsheet / --report-dir / --log-level` | 可选 | 跳过绩效图、指定输出根目录（默认本目录 results/）、调整框架日志（默认 WARNING） |

### 数据要求

需要角色表、fut_basic.feather、fut_adjustment_factors.feather 和每日主力行情；换约日还需旧主力行情。因子字段为 trade_date、code、symbol、pcr_cumfactor，按上游已对齐的当天口径使用；合约冲突时以因子 symbol 为准，不再次累计 pcr_factor。

期货角色表默认查找 fut_contract.feather，缺失时兼容 fut_contract_data.feather；两者同时存在需通过 --contract-struct 选择。基础条款默认 fut_basic.feather，行情为 `<symbol>_YYYYMMDD.feather`。

### 输出内容

默认保存到本策略目录的 `results/<run-id>/`，可通过 `--report-dir` 修改根目录。控制台输出数据准备、运行回测、报表与清理的阶段耗时。

| 输出文件 | 内容 |
| --- | --- |
| orders.csv | 模拟委托及订单状态 |
| fills.csv | 实际模拟成交；提交目标不等于成交 |
| positions.csv | 真实合约持仓记录 |
| account.csv | 模拟账户及资金记录 |
| summary.json | 回测摘要、策略参数、信号或调仓统计 |
| input_manifest.json / input_coverage.json / input_issues.json | 输入版本、覆盖与质量诊断 |
| tearsheet.html | 可选绩效图；省略 --no-tearsheet 且绘图依赖可用时生成 |

### SimNow 接入增量验证

在运行环境中验证当前 `MainEmaStrategy` 与已有 CTP 执行组件的衔接：

```bash
python -u tests/run_main_ema_simnow.py --stage all
```

集中入口按阶段启动独立进程，失败即停止，打印实际 Python、Bomber、策略及公共 Runner 加载路径。单独复测某一模块时，将 `all` 替换为下表中的阶段名；`--timeout` 可选，默认每个阶段或回归脚本 180 秒。

| 阶段 | 验证内容 |
| --- | --- |
| signal | 当前策略的预热、方向、目标去重、合约过滤、角色发布时间及累计因子，共 6 项 |
| routing | LIVE 固定主力路由：默认行为、目标推进和版本、在途及恢复约束、过期目标、行情时间、资料缺失、主力变更闭闸、行情恢复确认及 LIVE 动态路由禁用，共 10 项 |
| ctp | 内存传输下复用原生 CTP Driver、公共限价规划器与受控客户端：LIVE 固定路由验证开仓／平今／反手、最新信号、部分成交／撤单、断线及主力变更关闭授权；HISTORICAL 单独验证跨合约换约，共 7 项 |
| regression | 复用 7 个相关旧回归入口，检查公共修改对既有链路的影响 |

上述验证不连接 SimNow 或发送柜台订单，结果只证明无网络场景。公共 [FixedRoleLiveRunner](../../bomber/framework/trader/live_roles.py) 通过 `add_role_strategy` 装配单策略、固定角色合约的 LIVE 路由。角色、参考源、逻辑目标键及策略处理时间回调显式传入，可供其他单角色策略复用。在新 Bar 决策后推进尚未完成的目标，不增加策略或组合贡献版本；角色合约变化时关闭授权、请求撤单并标记需恢复，资料不可用时暂停目标推进。LIVE 动态换约限制继续保留。

当前目录中，`strategy.py` 定义策略，`run_backtest.py` 组装回测，`run_live.py` 是唯一实盘组装文件。原 `live_references.py`、`live_runner.py` 已删除：文件／数据库参考适配由公共 [FileRoleReferences／SourceRoleReferences](../../bomber/framework/dataprep/live_role.py) 提供；运行路由及会话守卫由公共 `FixedRoleLiveRunner／SessionRoleLiveRunner` 提供。PF2026100807进一步将在线生命周期移入公共Runtime，两个入口统一使用执行组件与绑定声明，策略文件保持不变。

PF2026100806修正版远程验收已通过：references30/30、routing10/10、CTP7/7、entry35/35，共82项，报告main-ema-acceptance-1791458768127640128。这是PF2026100807重构前的证据；新版本按[本次组装迁移清单](SIMNOW_ACCEPTANCE.md#统一组装结构pf2026100807)同步并远程复验后，再使用第二套Recording和受控模拟订单命令。实际柜台成交与最终对账仍待验收。

2026-10-08第二套MD原始／标准行情及TD只读已远程通过。显式`--simnow-environment replay --replay-md-trading-day YYYYMMDD`以Tick实际接收时间聚合Bar，保留原始Tick时间；MD／TD分别固定各自会话日，资料按实际TD日／当前可用时间加载。默认realtime仍用事件时间和MD／TD同日检查，请求120秒时效及执行门控保留。迁移前entry34/34及真实第二套Recording已通过：832条Tick、9根Bar、LONG 1手目标、报单0，停机总仓空且无活动订单。历史失败修正见[单实盘入口迁移](SIMNOW_ACCEPTANCE.md#单实盘入口迁移pf2026100806)。

### 回测与实盘的共同组装方式（PF2026100807）

两个入口都遵循：准备输入 → 执行组件 → 同一个MainEmaStrategy → StrategyBindings → Runner → Runtime.run/stop。参考服务负责查询角色和因子，执行组件负责共享仓位及真实参考价，绑定声明负责决定数据进入哪个策略、目标进入哪个执行通道。

| 积木 | 回测选择 | SimNow选择 |
| --- | --- | --- |
| 参考服务 | prepare_role_research生成as-of快照，文件trading/aligned | FileRoleReferences或SourceRoleReferences；数据库默认source/source-day-end |
| 行情 | FileReplayFeed，标准真实合约Bar | CtpLiveDataFeed + TradeTickBarFeed；第二套显式选择接收时间Bar |
| 执行构建 | build_simulation_execution + 模拟Backend | build_ctp_execution + 原生TD Driver；默认Recording，显式授权后受控执行 |
| 公共绑定 | StrategyBindings + assemble_strategy | 同左；固定角色额外声明RoleGuard |
| Runner | UnifiedStrategyRunner(HISTORICAL)，动态路由 | SessionRoleLiveRunner，固定本次角色及条款 |
| Runtime | UnifiedHistoricalRuntime，保持行情撮合先于策略 | ManagedLiveRuntime + CtpSessionLifecycle |
| 结果 | 回测CSV、摘要与可选绩效图 | LiveRunReport、目标／执行回报、停机权威查询 |

公共入口：[绑定声明](../../bomber/framework/trader/assembly.py)、[执行构建](../../bomber/framework/trader/execution/builders.py)、[在线Runtime及控制器接口](../../bomber/framework/trader/runtime/managed.py)、[CTP生命周期](../../bomber/framework/trader/runtime/ctp.py)、[在线报告](../../bomber/framework/trader/runtime/reports.py)。新组件通过各自模块直接导入；原RuntimePort、DirectLiveRuntime及公共包导出保持不变。

`run_backtest.assemble(...)`完成策略链组装，返回runtime、strategy、client；`run_live.assemble(...)`完成同样的策略链组装，`build_runtime(args)`再注入输入工厂、CTP控制器和报告。构造阶段不连接、不授权、不发单，启动统一交给Runtime。回测入口保留模块及直接脚本运行；实盘继续使用`python -m demos.01_main_ema.run_live`。

CTP控制器负责账户锁、只读预检、最终会话、就绪、授权、持续对账和停机。主力EMA同时持有公共bomber-ctp账户锁及旧bomber-main-ema锁，使其他使用公共CTP控制器的策略和旧入口进程都受互斥约束。输入工厂将数据库close登记到Runtime的ExitStack，读取或组装失败也释放资源；持久化钩子在最终TD启动前安装。停机仍撤单并报告剩余仓位，不自动平仓，也不接管带仓账户或旧状态。

其他单角色策略可替换策略实例、目标键、角色和处理时间回调，使用相同绑定及执行组件。其他在线通道可实现LiveSessionControllerPort并复用ManagedLiveRuntime。Binance专用控制器、LIVE动态换约、多账户及多腿会话不在此次实现范围；不能只更换名称就绕过对应的生命周期要求。

公共变化已在[并行协调记录PF2026100807](../../doc/HANDOFF/coordination/HANDOFF_PARALLEL_BACKTEST_LIVE_2026-10-07.md#pf2026100807-回测与实盘采用一致的组装结构)登记并在当前对话通知；跨任务待同步。本轮只完成源码与静态核对，没有本机Python／编译／测试结果。

随后远程五组已全部通过，报告main-ema-acceptance-1791463560272015358：assembly10、routing10、CTP7、entry38共65项单元测试及原runtime委托验证退出0，公共新模块／两入口／相关测试摘要一致。当前没有新源码修改，已通过组无需重复。下一步新入口第二套Recording复验，再受控模拟订单；完整Nautilus样本报表对比及真实柜台成交仍单独待验收。日志中的failed摘要属于预期异常测试，不能解释为实际模拟会话失败。

2026-10-07 远程验证状态：Linux `uv-nautilus` / Bomber 1.230.0 环境下，signal 6/6、修正版 routing 10/10（0.007 秒）、修正版 CTP 7/7（0.021 秒）及 regression 的 7 个相关旧入口全部通过。CTP 首轮 HISTORICAL 换约用例因漏掉旧合约行情推进的撤单阶段而失败，修正事件顺序并补充旧仓未平前禁止开新仓的断言后复验通过。合计 23 项增量用例及 7 个相关回归入口已有远程无网络通过证据，可进入下一模块，已通过的阶段无需重复运行。SimNow 行情与实际柜台交易尚未验收。

下一模块复用既有交易端只读探针。在项目根目录、已激活的 `uv-nautilus` 环境中，使用项目 `.env` 或当前环境变量配置的 SimNow TD：

```bash
python -u -m scripts.integration.ctp.td_readonly --connect --timeout 30
```

该命令执行登录、结算确认和本次仓位／资金／全账户活动订单查询，不发单；读取 `CTP_TD_ADDRESS`、`CTP_BROKER_ID`、`CTP_ACCOUNT_ID`、`CTP_PASSWORD` 及既有认证配置，不在命令中填入凭据。以三项查询完整完成为此模块的验收依据；失败时先反馈完整脱敏输出，不沿用历史柜台快照。通过后继续当前主力 EMA 的实时行情到 Recording 装配，再接受控模拟订单。

通道只读入口已归入 [scripts/integration/ctp](../../scripts/integration/ctp/README.md)，开发时先以 `python -u -m tests.run_ctp_td_readonly` 验证新入口配置定位、三查询与禁单，再连接柜台。该模块命令须在项目根目录运行，使用已同步的 `bomber/__init__.py` 开发加载文件与 `bomber/framework`；只读入口及烟测不要求部署旧 examples 目录，也不在源码注入 `sys.path`。目录调整见[协调记录 PF2026100702](../../doc/HANDOFF/coordination/HANDOFF_PARALLEL_BACKTEST_LIVE_2026-10-07.md#pf2026100702-通道联调入口归入-scripts-integration)。

当前增量同步以[单实盘入口迁移清单](SIMNOW_ACCEPTANCE.md#单实盘入口迁移pf2026100806)为准，远程须删除两个旧辅助文件。CTP 增量使用公共 `CtpLimitPlanner`，不依赖 examples。原目标推进的变更与历史验证状态见[并行协调记录 PF2026100701](../../doc/HANDOFF/coordination/HANDOFF_PARALLEL_BACKTEST_LIVE_2026-10-07.md#pf2026100701-保留目标的分阶段执行推进)。

2026-10-08 用户远程运行 `python -u -m tests.run_ctp_td_readonly`，假 API 的配置定位、登录／结算确认、三项查询和禁单全部通过。后续集中验收前8组全部退出码0；entry原17项中14项通过、3项因测试时钟未绑定到受控客户端而失败。在线入口已显式传入时钟回调，保留120秒限制并新增过期请求闭闸验证，修正版18项待以 `python -u -m tests.run_main_ema_acceptance --only entry` 复验。通过后再按接入验收文档运行当前柜台只读及主力 Recording。

随后远程entry复验18/18通过（0.421秒），本轮9组离线模块均有通过证据。真实TD只读查询完成，净仓合约0、CNY资金快照和活动订单0。文件模式Recording在默认trading口径下缺少2026-10-08／RB／main累计因子，尚未连接MD并产生Bar。该失败是历史文件输入证据；原始数据库日期最新澄清为source，不要求补造TD日因子。数据字段、日期口径修正及证据见[接入验收](SIMNOW_ACCEPTANCE.md)。

2026-10-08 实盘入口新增可选 `--reference-source dolphindb`，读取期货条款及此前来源日期限结构／同日累计因子，数据库默认 `--factor-date-basis source`。文件模式默认trading用于已对齐适用日的输入；可显式切换日期口径，回测默认不改。EMA策略代码未修改，条款生命周期仍按TD当前日验证。默认source-day-end可用性，已有available_ns优先门控。字段映射、环境变量、日期修正版验证与远程步骤见 [参考数据库核验](../../scripts/integration/reference_data/README.md)。

PF2026100810：第一套实时SimNow夜盘可显式使用`--factor-availability observed-on-read`配合`--reference-source dolphindb --factor-date-basis source --expected-source-day YYYYMMDD`。该口径从两轮一致的当前数据库读取完成时起使用快照，数据库实际`available_ns`仍会延后放行；默认source-day-end继续保留。回放和文件入口不接受该选项。先按[SimNow验收步骤](SIMNOW_ACCEPTANCE.md)完成离线、只读和Recording，再进行独立受控报单验收。

GAP-03更新：在线默认dolphindb，一次性Recording／simnow须声明按日历核对的`--expected-source-day`；持续模式由各会话日历确定。文件资料测试须显式`--reference-source file --allow-file-reference-test`，不作自动回退。来源年龄默认14自然日、成功观测30秒、单轮刷新30秒，可分别用`--reference-max-source-age-days`、`--reference-max-observation-seconds`和`--reference-max-refresh-duration-seconds`调整；真实available_ns继续门控。代码及远程验收见 [GAP-03交接](../../doc/HANDOFF/gaps/HANDOFF_GAP03_2026-10-09.md)，本机未运行。

## 2. 策略详细说明

### 策略思路与交易对象

这是单品种趋势方向策略：用快、慢 EMA 的相对位置决定持仓方向，信号与交易均对应当前主力。它判断的是当前均线关系，预热结束后即使没有观察到一次交叉，也可以建立首笔仓位。

| 项目 | 具体规则 |
| --- | --- |
| 研究价格 | 当根主力真实收盘价 × 当天 `pcr_cumfactor` |
| 有效事件 | 事件时刻快照可用，合约与交易所匹配当前主力，时间晚于上一有效主力 Bar |
| 信号周期 | `fast`、`slow` 均按有效主力分钟 Bar 计数；不是自然分钟或交易日 |
| 预热 | 慢 EMA 的 `initialized` 为真后才允许提交目标 |
| 多头 | 快 EMA ≥ 慢 EMA，目标 `+quantity` |
| 空头 | 快 EMA < 慢 EMA，目标 `-quantity` |
| 目标更新 | 仅当目标方向变化时重新提交；同方向不会逐根加仓 |

每根有效价格同时更新两条 EMA，指标计算由 Bomber 的 `ExponentialMovingAverage` 实现。缺少可用角色快照时跳过并计数；旧主力 Bar 和重复时间事件不推进指标。

### 仓位、换约与退出

策略提交的是 `rb_main` 等逻辑目标，动态执行路由将它解析到真实月份合约。若实际持仓为 +1 手、目标变为 -1 手，执行层根据持仓差额规划反向交易；策略并非只发一手卖单。

主力切换时保留两条 EMA 和此前方向，通过累计因子保持研究序列的连续口径；执行路由协调旧主力退出和新主力仓位。换约日的旧合约行情用于执行，不参与新主力的 EMA。因子表与角色表冲突时，数据准备层采用因子表合约，避免研究与执行身份不一致。

`strategy.position(config.target_key)` 查询本策略已归属的实际仓位。`on_order(OrderUpdateEvent)` 接收受理、部分成交、全部成交、撤单及拒单等订单状态；订单、账户、在途和归属先更新，再通知策略，订单回调先于对应 `on_fill(FillEvent)`。本例保存 `order_updates_received`、`last_order_update` 和回调内 `last_order_position`，成交回调保存 `last_fill_position` 与 `fills_received`。订单累计成交量属于状态事实，不能在回调中再次累加仓位。

新策略推荐重写 `on_order`。模板默认将它转发给旧 `on_order_update`，既有策略保持兼容；同时重写两者时只自动调用 `on_order`，需要父类行为时显式使用 `super().on_order(event)`。历史换月按旧、新真实合约分别入账，再汇总到同一逻辑目标。在线固定路由下，`account_position` 查询账户净仓；正常单策略会话应与归属仓位一致。在线 `summary.json` 提供 `strategy_position`、`account_position`、`unassigned_position`、订单回调次数及最后状态／订单 ID／原因／仓位、成交回调观测字段。非零未归属差额需核验接管或订单关联，不能当作策略已成交仓位。

本例没有中性区、独立止盈止损或末日强制平仓。方向改变是主要退出及反向条件，回测末尾可能仍持仓。检查结果时应同时查看有效 Bar 数、最终主力、目标方向及 `fills.csv`、`positions.csv`，不能仅凭最终 target 判断成交。

## 3. 使用核心组件描述

### dataprep：输入准备

负责加载和校验文件，把本例需要的资料及真实行情准备好，不计算 EMA、不启动回测。

| 关键接口 | 本例用途 |
|---|---|
| input_session / read_feather | 共享本次运行的读取缓存、文件版本和输入诊断 |
| resolve_futures_args | 返回 DataPaths，定位行情目录、角色表和基础条款 |
| prepare_role_research | 只准备当前品种的 main 信号与执行角色；加载当天累计因子，合约冲突时以同角色因子 symbol 为准，组装 DataHub Store |
| futures.instrument | 校验真实条款，调用 trader 合约工厂，返回原生合约、行情元信息和乘数 |
| BarReadSpec / bar_path / add_bar_source | 定位必需文件，统一一分钟时间标签、严格校验 OHLCV，将准备好的行注册到 market Feed |
| write_input_reports | 写出输入版本、日期覆盖和问题，便于对照交易报表 |

### datahub：参考资料查询

负责保存 dataprep 准备的参考资料，按策略事件时间查询；不回放行情、不生成订单。

| 关键接口 | 本例用途 |
|---|---|
| SectorRoleAssignment | 保存交易日、角色来源日、生效及可用时间、最终真实合约映射和累计因子 |
| SectorRoleStore | 管理日级快照，供策略按时间查询；文件加载及冲突覆盖由 dataprep 完成 |
| snapshot(timestamp) | 查询事件时刻已生效且可用的角色快照 |
| instrument(product, "main") | 从快照取得当前品种的最终真实主力合约 |
| factor(product, "main") | 从快照取得当前主力的累计复权因子，供 EMA 研究价格使用 |
| SectorDataUnavailable | 参考资料尚不可用时通知策略跳过事件并计数，不补因子或生成目标 |

### market：行情定义和回放

负责真实行情的数据结构、解析和文件回放；保留真实价格，复权只在策略计算信号时使用。

| 关键接口 | 本例用途 |
|---|---|
| InstrumentMeta | 描述真实合约的价格精度、最小变动、乘数、币种和交易所 |
| DataType.BAR / Bar | 声明分钟行情类型，向策略提供真实 OHLCV、合约身份和事件时间 |
| FileReplayFeed | 管理并回放 dataprep 注册的数据源；换月当日包含旧、新主力行情 |
| FixedInstrumentBarParser / MappedBarParser | 将准备好的行解析为固定真实合约 Bar，映射事件时间和可用时间 |

当前主力 Bar 用于 EMA，旧主力 Bar 用于换月执行；连接行情与模拟后端的 NautilusMarketFeedAdapter 属于 trader。

### trader：策略运行和模拟执行

负责把行情、策略目标、真实合约路由、仓位和模拟后端连接起来。

| 关键接口 | 本例用途 |
|---|---|
| StrategyTemplate | 策略基类；set_target 提交逻辑目标仓位，例如 rb_main |
| ScheduledContractResolver / DynamicExecutionRoute | 按生效时间映射真实主力，协调换月旧仓处理与新合约目标 |
| PositionManager / NetTargetOrderPlanner | 区分策略归属、账户净仓及在途量，根据目标与有效仓位差额生成订单 |
| PositionAttributionLedger | 冻结订单成交分配、按真实合约更新策略归属，记录内部净额和未归属差额 |
| MarketReferencePriceStore / PreTradeRiskManager | 维护真实参考价，检查手数、名义金额和行情年龄 |
| NautilusMarketFeedAdapter | 将 market 行情连接策略回放与模拟后端；该适配器属于 trader |
| UnifiedStrategyRunner / UnifiedHistoricalRuntime | 注册数据和执行绑定，推进历史运行，管理停止清理 |
| instrument_factory / NautilusSimExecutionBackend / CtpFuturesBasicProfile | 构造原生合约并模拟执行；本例起始资金 1,000,000、每手手续费 1，采用基础保证金模型 |

## 显式接管已有一手仓位（PF2026100901）

默认仍须空仓启动。只有指定`--adopt-existing-position cu2611.SHFE --expected-position -1`时，才尝试将该合约的一手空仓分配给当前唯一策略。首版支持SHFE／INE、单合约单向一手投机仓；指定合约须等于本次主力，账户不能有其他仓位或活动订单。`--expected-position 1`表示多仓。入口要求realtime、明确TD日及参考来源日，并要求一手目标。

预检和正式登录后分别做两轮权威查询，检查净仓、总仓、今昨仓、资金及活动订单一致；从原生`PositionCost`和乘数初始化成本账本。缺字段或仓位变化即拒绝。需要重新编译安装TD扩展，不能只更新Python文件。接管不恢复旧EMA和旧订单，重新收集完整分钟Bar预热。

已有空仓时，SHORT目标保持仓位；LONG目标先BUY平今／平昨。平仓全部成交且本地执行账本归零后，后续有效Bar再推进最新目标；目标仍为LONG才开多，不提前发送开仓单。原有重复成交去重、行情健康、参考资料检查和风控继续生效。

建议先用Recording加接管参数验证：不发单，实际空仓保留。离线与Recording通过后，SimNow命令沿用已确认的CU参数，增加：

```bash
--adopt-existing-position cu2611.SHFE --expected-position -1 \
--quantity 1 --max-notional 600000 --max-session-orders 2
```

SimNow还须`--enable-orders --confirm-simnow`及一个不存在的新`--state-file`。两笔预算分别用于平空和开多；平仓未成交或信号一直同向时，不能认定反手验收完成。停机只撤活动订单和报告权威剩余仓位，不自动平掉新多仓。重启需重新核验并声明当时实际方向。


## 公共Live机制（PF2026101033）

01和04共同使用公共环境时间策略、逐合约深度门控、CTP配置、控制线程参考缓存及恢复今昨仓解析，继续沿用ManagedLiveRuntime/CtpSessionLifecycle和公共执行装配。默认realtime检查事件及接收时效；显式replay按接收时间聚合，仍核对原始MD交易日及每合约深度。两入口均支持`--instrument-max-age-seconds`，默认10秒，范围(0,120]；全局MD接收门控仍为10秒。

数据库参考只在启动／控制线程刷新，行情回调读取有时效约束的原子缓存；刷新失败闭闸。01额外核对累计因子版本，改变后须重新装配。策略公式、EMA历史预热和04同步帧各保留原实现。源码完成，完整原生集成回归及在线验收待运行机验证；详见[公共化交接与修改文件清单](../../doc/HANDOFF/live/HANDOFF_LIVE_COMMON_2026-10-10.md)。


## Live渠道分离（PF2026101035）

在线运行时已迁移至`bomber/framework/trader/runtime/live/`，行情与执行来源分别
装配；CTP实时/7×24回放规则在`channels/ctp.py`，不会传入策略算法。原启动参数
兼容。旧runtime导入文件只重导出新实现；部署须包含新增live目录，不能只同步demo。

本机48项纯Python回归通过，原生集成受Bar实体缺失限制，需在uv-nautilus复测。
完整文件列表、时间策略和复测命令见
[Live渠道交接](../../doc/HANDOFF/live/HANDOFF_LIVE_CHANNELS_2026-10-10.md)。


## 策略持仓与恢复公共化（PF2026101036）

realtime/Replay均支持显式一手接管与单次同交易日`--resume`；恢复归属/账本/目标版本，EMA重新预热，旧目标在新信号前暂停。新状态含会话身份，旧单次文件缺身份组件不自动恢复。两demo源码不相互引用；行情模式与持仓初始化独立。账户仍单策略独占，失败恢复保留原文件。接管/恢复后新目标等于已有仓位时允许无新增订单，报告区分持仓核验与新成交；空仓新会话仍要求成交验收。

69项公共纯Python测试通过，9项新增原生实体装配测试及实际柜台接管/恢复待Linux验收。本例修改清单、同步摘要、回归和当前命令见[持仓恢复交接](../../doc/HANDOFF/live/HANDOFF_LIVE_POSITION_RECOVERY_2026-10-10.md)。
