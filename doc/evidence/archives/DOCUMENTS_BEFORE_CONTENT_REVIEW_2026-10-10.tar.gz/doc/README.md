# Bomber 项目文档导航

这里按主题组织系统设计、数据契约、策略方案、外部接口、架构审查与交接记录。先根据下面的阅读入口选择主文档，再进入对应专项；文档中的设计、实现和验收是不同状态。

整理日期：2026-10-10，Asia/Shanghai。原有 16 份专题文档、37 份交接文档和 54 份校验及补丁材料已分类迁移。新旧路径见 [迁移说明](MIGRATION_2026-10-10.md)。

## 从哪里开始阅读

| 需要了解什么 | 首选入口 | 阅读说明 |
| --- | --- | --- |
| 项目整体结构和实现进度 | [统一策略架构与状态台账](architecture/STRATEGY_ARCHITECTURE.md) | 框架模块、运行链路、实现及验证进度的主要入口 |
| 系统目标和职责边界 | [系统目标架构](architecture/ARCHITECTURE_FIXED.md) | 区分目标设计与已经实现的能力 |
| 当前架构缺口 | [GAP 评估快照](audits/ARCHITECTURE_GAP_REVIEW_2026-10-09.md) → [完整跟踪清单](audits/ARCHITECTURE_GAPS_2026-10-09.md) | 前者便于掌握评估时状态，后者保留逐项验收标准及过程 |
| 九个策略及公共输入层 | [策略框架交接](HANDOFF/demos/HANDOFF_DEMOS_FRAMEWORK_2026-10-07.md) → [输入层实现记录](strategies/DEMOS_INPUT_STAGE1_IMPLEMENTATION_2026-10-04.md) | 具体入口和参数继续查各 demo 的 README |
| 当前 Live 渠道及策略恢复 | [渠道分层](HANDOFF/live/HANDOFF_LIVE_CHANNELS_2026-10-10.md) → [持仓接管与恢复](HANDOFF/live/HANDOFF_LIVE_POSITION_RECOVERY_2026-10-10.md) → [REV3 验证证据](HANDOFF/live/HANDOFF_LIVE_REV3_EVIDENCE_2026-10-10.md) | 按源码版本和验收范围阅读，离线结果与实际柜台结果分别确认 |
| 历史预热和盘中回补 | [历史启动规则](HANDOFF/history/HANDOFF_HISTORY_STARTUP_POLICY_2026-10-09.md) → [Provider 实施](HANDOFF/history/HANDOFF_HISTORY_PROVIDER_2026-10-09.md) → [历史数据交接索引](HANDOFF/README.md#历史行情预热与恢复) | 后续规则补充了早期架构中的“在线历史仅本地”表述 |
| 与 DXBM LXG 系统对接 | [接口规范](integration/DXBM_LXG_INTEGRATION_SPEC.md) | 双方评审草案，包含建议契约与验收标准 |
| 接续某个具体任务 | [交接记录索引](HANDOFF/README.md) | 按主题找交接，再核对对应版本和证据 |
| 同步或定位旧文件 | [证据材料索引](evidence/README.md)和[路径对照](MIGRATION_2026-10-10.md#新旧路径对照) | 校验清单从项目根目录使用；原始材料已备份 |

## 文档分类

| 目录 | 内容 | 原有材料数量 |
| --- | --- | --- |
| [architecture](#架构与实现台账) | 系统目标架构、统一框架与实现进度 | 2 |
| [data](#数据契约与会话规则) | DataHub、基础条款、期货期权数据、交易会话 | 4 |
| [strategies](#策略与公共输入设计) | 示例适配、输入层设计和实现交接 | 3 |
| [integration](#系统对接与技术评估) | 外部系统接口和行情技术选型 | 2 |
| [audits](#架构审查与缺口) | GAP 清单、评估快照、品种专用代码审查 | 3 |
| [archive](#历史架构与进度快照) | 早期架构讨论、历史进度报告 | 2 |
| [HANDOFF](HANDOFF/README.md) | 按策略、实盘、历史、GAP、协调及历史记录细分 | 37 |
| [evidence](evidence/README.md) | 校验清单、补丁与同步脚本 | 54 |
| [source_snapshots](source_snapshots/README.md) | 第一阶段迁移前源码快照及校验清单 | 原始目录保留 |
| [phase1_baseline_2026-10-04](phase1_baseline_2026-10-04/README.md) | 第一阶段基线压缩包及文件摘要 | 原始目录保留 |

## 架构与实现台账

| 文档 | 用途和状态 |
| --- | --- |
| [ARCHITECTURE_FIXED](architecture/ARCHITECTURE_FIXED.md) | 目标架构基线，定义系统分层和职责；实现进度另查状态台账 |
| [STRATEGY_ARCHITECTURE](architecture/STRATEGY_ARCHITECTURE.md) | 统一策略框架主文档，含 Runtime、Market、Backend 边界、模块职责和阶段状态 |

## 数据契约与会话规则

| 文档 | 用途和状态 |
| --- | --- |
| [DATAHUB_MINIMAL_CORE](data/DATAHUB_MINIMAL_CORE.md) | 参考研究数据最小查询核、时间可见性和分阶段验收 |
| [BASIC_METADATA_ALIGNMENT](data/BASIC_METADATA_ALIGNMENT.md) | 期货期权基础条款在 datahub、dataprep、trader 各层的结构与接口对齐 |
| [FUTURES_OPTIONS_DATA_CONTRACT_ANALYSIS](data/FUTURES_OPTIONS_DATA_CONTRACT_ANALYSIS_2026-10-09.md) | 数据需求及格式草案，区分会话通用化与完整数据适配范围 |
| [TRADING_SESSION_GENERALIZATION](data/TRADING_SESSION_GENERALIZATION_2026-10-09.md) | 交易日历、会话模板、品种绑定及特殊日期覆盖的设计；交接细节见对应专项 |

## 策略与公共输入设计

| 文档 | 用途和状态 |
| --- | --- |
| [STRATEGY_EXAMPLES_FRAMEWORK_ANALYSIS](strategies/STRATEGY_EXAMPLES_FRAMEWORK_ANALYSIS.md) | 早期 example 系列到统一框架的能力映射与迁移规划；旧“当前缺口”须结合新台账阅读 |
| [DEMOS_INPUT_RUNTIME_DESIGN](strategies/DEMOS_INPUT_RUNTIME_DESIGN_2026-10-04.md) | 公共输入与运行层两阶段设计，含工作包、契约和验收矩阵 |
| [DEMOS_INPUT_STAGE1_IMPLEMENTATION](strategies/DEMOS_INPUT_STAGE1_IMPLEMENTATION_2026-10-04.md) | 第一阶段实现、命名及目录迁移记录，后续补充了远程回归和单策略结果；各版本单独验收 |

## 系统对接与技术评估

| 文档 | 用途和状态 |
| --- | --- |
| [DXBM_LXG_INTEGRATION_SPEC](integration/DXBM_LXG_INTEGRATION_SPEC.md) | v0.8 双方评审草案：订单命令、回调、策略归属、恢复和能力声明；不代表适配器已实现 |
| [MARKET_DATA_CYTHON_EVALUATION](integration/MARKET_DATA_CYTHON_EVALUATION.md) | 行情源是否采用 Cython/PYD 的选型评估与冷热路径分层分析 |

## 架构审查与缺口

| 文档 | 用途和状态 |
| --- | --- |
| [ARCHITECTURE_GAP_REVIEW](audits/ARCHITECTURE_GAP_REVIEW_2026-10-09.md) | 2026-10-09 的评估快照，明确区分当前实现、已验版本和未完成验收 |
| [ARCHITECTURE_GAPS](audits/ARCHITECTURE_GAPS_2026-10-09.md) | 完整问题清单、验收标准及关闭记录，包含历史状态 |
| [PRODUCT_SPECIALIZATION_AUDIT](audits/PRODUCT_SPECIALIZATION_AUDIT_2026-10-09.md) | CU/IM 等品种专用实现及公共层场景固定的源码审查，为会话通用化提供依据 |

## 历史架构与进度快照

| 文档 | 保留原因和替代入口 |
| --- | --- |
| [ARCHITECTURE](archive/ARCHITECTURE.md) | 保存早期设计与演进讨论；目标边界优先查 ARCHITECTURE_FIXED，实现查 STRATEGY_ARCHITECTURE |
| [PROJECT_PROGRESS](archive/PROJECT_PROGRESS.md) | 截至 2026-09-22 的进度快照；后续进度查状态台账及对应专项交接 |

两份架构文档大段重叠，但各自保留了不同的演进信息，因此归档旧稿并保留全文。两份会话通用化文档也各有用途：data 下保存需求和契约，HANDOFF 下保存接手任务与资料清单。

## 文档状态如何判断

目标架构回答“系统应当如何工作”，状态台账回答“已实现和已验证到哪里”，专项交接回答“某次修改和证据覆盖什么范围”。日期可能表示初稿或计划执行日；例如文件名含 2026-10-12 的盘中回补交接编制于 2026-10-09，记录的是计划，不是完成结果。

旧段落保留了当时状态。阅读时优先看同一文档的最新结论，再核对后续专项与修订证据；离线回归、数据库只读、Recording 和实际 SimNow 成交的结论各自只覆盖已声明范围。

## 后续文档维护

- 架构职责与实现状态分别维护在 architecture 的两份主文档；详细任务过程放到 HANDOFF 对应主题。
- 新设计按主题存入 data、strategies 或 integration；审查结果存入 audits。
- 被后续版本替代的总结放入 archive，并在导航中注明替代入口；原文中的历史证据继续保留。
- 同步校验清单放入 evidence/checksums，补丁及删除清单放入 evidence/patches；文件摘要更新必须注明范围。
- 新增或移动文档时，同时更新本文或交接索引，并核对 Markdown 链接和项目根目录命令中的路径。
