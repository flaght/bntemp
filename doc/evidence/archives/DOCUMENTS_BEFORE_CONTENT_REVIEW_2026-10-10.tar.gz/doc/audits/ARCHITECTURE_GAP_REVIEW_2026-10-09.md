# 当前 GAP 评估快照

评估日期：2026-10-09，Asia/Shanghai。本次更新以当前源码及已登记到 PF2026100924 的交接证据为准，覆盖 `bomber/`、`demos/` 与相关联调入口。只修改本评估文档；未修改运行代码，未运行 Python、测试、编译，也未连接数据库或柜台。远端通过／失败结论依据项目登记的用户反馈，并非本次独立重跑验证。

基线为 [整体 GAP 清单](/Users/kerry/work/bomber1/pro/doc/audits/ARCHITECTURE_GAPS_2026-10-09.md)、两份总体架构文档及用户后续正式澄清。共享清单保留了大量历史状态，本文区分当前实现、已验版本和未完成验收；不以旧段落推断当前代码仍不存在相应能力。

## 当前结论

**11 项中，GAP-01、GAP-03 已按既定范围关闭，其余 9 项仍开放。本轮没有新增整体关闭项。**

相较上一版评估，主要进展是 GAP-04 的历史因子、真实指标停机重启和正式 IM Recording 装配，以及 GAP-05 的单 CTP 多品种运行与保留目标续执行。GAP-01 又取得真实反手成交片段；GAP-02 完成更深入的根因分析。上述进展不能合并推称完整生产恢复、通用组合执行或 CTP＋BN 联合在线交易已经通过。

当前最直接的验收阻塞是 04 横截面运行／测试部署版本不一致。最新补齐清单与预检已交付，尚无修正后通过结果。期货／期权会话通用化仍是独立专项，不新增整体 GAP 编号，不计入关闭数量。

## 逐项状态与变化

| GAP | 当前判断 | 本轮更新／当前已有能力 | 剩余关闭条件 |
| --- | --- | --- | --- |
| 01 成交归属 | 已按既定范围关闭 | 首次 EMA 实盘模拟成交与最终权威仓位核对已有完整记录；新增 CU 夜盘开空、平今、保留 LONG 目标再开多的真实片段 | 新片段缺最终 summary 与停机后权威查询；不据此扩大为共享账户、完整恢复均已实测 |
| 02 目标截止时间 | 根因分析完成，修复未实施 | 已明确普通／动态入口、执行时钟、期限传播、实际发送及共享账户过期贡献问题 | 贯通目标接收、内部归属、逐笔发送、在途到期处置和恢复；按最终修改范围验收 |
| 03 数据源边界与一致性 | 已按既定范围关闭 | 来源政策、参考时效、失效闭闸及真实 CU 数据库→导出→本地一致性已通过 | 日常来源日／发布窗口核验继续执行；历史与通用特征分别归 04／08 |
| 04 历史预热与实时接续 | 实现及验证明显推进，未整体关闭 | 逐日固定合约因子、239 根真实 IM 预热、实际进程指标重启／数据库回补通过；正式 IM Recording 装配 6 项离线通过 | 正式当前在线历史→实时接续；生产账户／订单恢复；CFFEX 报单未开放，MongoDB 仍占位 |
| 05 多腿协调与续执行 | 已有单端多品种链路，通用协调仍缺 | 04 支持五品种自动选主力；普通固定多目标续执行已扩展到独占单 Client 的多个静态路由；逐合约价格最小变动单位接入 | 最新部署与 27 项回归、真实同步 Recording；通用组合状态、裸腿限制、部分成交／超时／补偿及跨端协调 |
| 06 在线重启与恢复 | 局部恢复增加，生产闭环未验收 | CU 持续模式受限 resume 已有；新增实际 Python 停机后指标恢复与分钟回补证据 | 完整交易状态同代恢复、实际日夜盘／断线接续、漏成交／未知／消失订单重建，以及双端恢复 |
| 07 执行语义与风控 | 基础能力扩展，范围仍受限 | CTP 今昨仓／限价、资金门控与基础风险已有；增加多合约 tick 映射，CU 夜盘平今及续执行有真实片段 | 通道能力、订单类型／TIF、套保、费用／保证金与组合风险一致性；新公共行情变更需受影响回归 |
| 08 自定义特征／DataHub | 核心缺口未见新实现 | 通用 ReferenceRecord／AsOfQuery 门面、参考 Store 与导出基础已有 | Schema 注册和标准导入、现货／指数绑定及对齐、通用 DolphinDB 特征 Provider、版本生命周期和消费场景验收 |
| 09 状态权威职责 | 正式设计决定仍缺 | CTP 使用框架状态服务；BN 原生 TradingNode 内部使用 NT，并回报框架 | 明确柜台权威、框架消费状态、NT 内部／镜像状态的一致性职责并更新契约 |
| 10 CTP＋BN 联合交易 | 首期代码及离线已验，联合在线待验 | 联合装配、共同闸门、权威查询、同机账户租约、HALTED 与显式剩余目标规划已有 | 双端当前只读／成交／最终仓位与失败恢复；BN 写前身份、漏成交重建及通用恢复；跨主机保护仍缺 |
| 11 Windows／Linux | 部署目标待统一 | 当前原生 CTP 构建及账户锁面向 Linux | 正式采用 Linux 则修订目标；仍需 Windows 则实现并验证相应构建／SDK／锁路径 |

## 主要进展与证据边界

### GAP-04：已超出原始分钟读取，仍缺正式在线闭环

PF0913—0915 接入历史价格调整与逐日固定合约因子。真实对象为 IM2610，历史日 2026-09-22、因子来源日 2026-09-21、因子 1.456591；不能把这一结果移用于 IM2611。整日要求 240 根、实际 239 根，缺 13:00，使用显式 allow 并保留 `coverage_complete=false`。主力／因子映射偏差及该缺口按用户约定暂缓，不在本评估中重新要求立即修复，也不将不完整覆盖记为完整通过。

PF0915 的实际 prepare／resume 是两次不同 Python 进程：保存 237 根指标后退出，恢复精确一致；数据库回补 14:58 到 238 根且 revision 仍为 0；14:59 新事件到 239 根、revision 为 1、内存目标 -1 一次，与连续 EMA 相同，重复事件被忽略。订单 0、不连接 CTP、不写交易状态。因此“实际指标进程重启”已经验收，“生产交易 Runtime 完整恢复”仍未验收。history-adjustment 32 项远端通过。

PF0916 已接通正式 IM／CFFEX Recording 装配，新增 6 项正式生命周期／历史接续离线用例及所选兼容回归通过。不能再写“股指入口未接通”。当前范围仍为 Recording；实际当前在线接续尚无通过记录，CFFEX 报单及持续交易恢复未开放。DolphinDB 当前只确认 CFFEX 原始分钟，CU 夜盘成交不能替代 IM 历史接续证据。

依据：[真实指标进程重启](/Users/kerry/work/bomber1/pro/doc/HANDOFF/history/HANDOFF_HISTORY_RESTART_2026-10-09.md)、[正式 IM 装配](/Users/kerry/work/bomber1/pro/doc/HANDOFF/history/HANDOFF_IM_RUNTIME_2026-10-09.md)、[下一交易日交接](/Users/kerry/work/bomber1/pro/doc/HANDOFF/history/HANDOFF_DOLPHINDB_INTRADAY_MONDAY_2026-10-12.md)、[历史服务](/Users/kerry/work/bomber1/pro/bomber/framework/dataprep/history/service.py)。

### GAP-05：单 CTP 多品种已实现，最新版本验收受部署阻塞

04 横截面已从离线 demo 推进到公共装配的 Live 入口，当前五品种为 CU／PB／NI／AU／AG；从本次 DolphinDB 参考自动选择主力并固定会话路由。公共 Runner 已支持独占单 Client、多个静态目标按当前合约新 Bar 推进保留目标，不能继续写成只有单目标续执行。该能力没有覆盖共享账户通用协调、动态换约或跨 Client 补偿。

最新证据必须按版本分开：

| 版本 | 已登记结果 | 当前判断 |
| --- | --- | --- |
| PF0920—0921 | 选定离线组通过；PF0921 cross-section 21 项通过 | 支持当时的五品种装配、自动选约和续执行实现 |
| PF0922 | 实际 Recording 报告 `cross-section-simnow-1791556990687918256` 失败，整体行情 HEALTHY，但 PB 成交 Tick 超龄；同步帧／报单均 0 | TradeTick 成交活性不能代替逐合约原始深度接收活性 |
| PF0922—0923 | 新增逐合约深度观察；过期成交 Bar 跳过，未来 Bar 闭闸并诊断；合计 27 项用例 | 新源码已有，尚无该一致版本离线通过及实际 Recording 通过记录 |
| PF0924 | 远端 27 项出现 failures 1／errors 17；测试已新、runtime 仍旧，run_live 缺 parse_args；已补齐 8 文件清单和接口预检 | 该轮未通过，且不能据此判定新版全部逻辑失效；先完成部署一致性，再验受影响链路 |

PF0923 的过期处理不填空分钟，不使用旧 Bar 交易，五腿同步仍要求真实同分钟成交 Bar。行情活跃度和迟发 Bar 两项局部修正不能代替同步帧、组合目标和最终报告验收。实际 Recording 尚未通过，也无五品种组合真实报单完成记录。

依据：[04 最新验收及 PF0924](/Users/kerry/work/bomber1/pro/demos/04_cross_section/SIMNOW_ACCEPTANCE.md)、[当前统一部署清单](/Users/kerry/work/bomber1/pro/doc/evidence/checksums/PF2026100924_SHA256.txt)、[续执行源码](/Users/kerry/work/bomber1/pro/bomber/framework/trader/runner.py:413)、[Bar 时效处理](/Users/kerry/work/bomber1/pro/demos/04_cross_section/live_runtime.py:103)。

### GAP-01／06：真实反手证据增加，不能推称完整重启通过

CU 夜盘片段确认三笔 ACCEPTED→FILLED：SELL OPEN 1@110600，BUY CLOSE_TODAY 1@110660，保留 revision 2 的 LONG 目标在下一 Bar BUY OPEN 1@110640。实际归属字段、柜台订单及成交 ID 已关联，支持先平后续开链路。

后续 generation 14 状态文件显示策略持仓与真实合约归属均为 0，但没有完整后续成交、最终 summary 或停机后柜台查询。不能称最终仍多 1，也不能用本地 0 代替当前权威空仓。本次为有限时长、history-minutes 0、非持续模式；该命令不保证保存完整 EMA 组件，不能据此宣称可直接自动续跑。

GAP-01 原关闭依据仍是已有完整 fresh EMA 首次成交及最终权威核对，不依赖上述不完整夜盘片段。GAP-06 的恢复仍要求已知订单与柜台事实一致，未知、消失及漏成交情况闭闸；一般故障重建尚未解决。

依据：[CU 夜盘成交与保存边界](/Users/kerry/work/bomber1/pro/doc/HANDOFF/live/HANDOFF_SIMNOW_CU_NIGHT_AND_NEXT_STRATEGY_2026-10-09.md)、[原完整首次成交验收](/Users/kerry/work/bomber1/pro/doc/HANDOFF/live/HANDOFF_FRESH_EMA_2026-10-09.md)、[活动订单恢复](/Users/kerry/work/bomber1/pro/bomber/framework/trader/execution/live/controlled.py)。

### GAP-02：已定位系统性原因，尚无修复交付

普通及动态主链仍调用 `TargetStore.apply(intent)`，未传处理时间。期限也未形成统一的订单／贡献契约，规划、写前持久化、队列及实际发送后仍可能越过截止时间；在途订单缺统一到期维护。

新分析尤其明确共享账户问题：A 的过期未完成目标可能随 B 的新目标轧差后继续执行，不能只检查 B 的 deadline，也不能直接将 A 目标清零，否则会制造新的平仓意图。修复须保留 GAP-01 的已成交归属与冻结母订单分配。该项当前是分析完成，未新增修复运行代码或专项验收。

依据：[GAP-02 根因及修复范围](/Users/kerry/work/bomber1/pro/doc/HANDOFF/gaps/HANDOFF_GAP02_2026-10-09.md)、[普通入口](/Users/kerry/work/bomber1/pro/bomber/framework/trader/runner.py:287)、[动态入口](/Users/kerry/work/bomber1/pro/bomber/framework/trader/runner.py:359)。

## 未发生实质关闭变化的项目

GAP-03 继续按来源政策／参考时效／导出一致性关闭，不扩大为任意特征集已实现。GAP-08 未见通用 Schema／数据集导入、现货／指数对齐及通用 DolphinDB 特征 Provider 新闭环。GAP-09、GAP-11 未见正式职责／部署目标决定。GAP-10 已有联合入口及 joint 24 项等离线证据，但未新增双端联合在线成交、最终权威仓位与失败恢复证据。04 的五品种属于同一 CTP 端，不能计为 CTP＋BN 联合验收。

依据：[GAP-03](/Users/kerry/work/bomber1/pro/doc/HANDOFF/gaps/HANDOFF_GAP03_2026-10-09.md)、[DataHub 门面](/Users/kerry/work/bomber1/pro/bomber/framework/datahub/temporal.py)、[GAP-10 交接](/Users/kerry/work/bomber1/pro/doc/HANDOFF/gaps/HANDOFF_GAP10_2026-10-09.md)、[联合入口](/Users/kerry/work/bomber1/pro/scripts/integration/ctp_binance/README.md)。

## 品种专用代码专项：独立跟踪

[交易会话通用化方案](/Users/kerry/work/bomber1/pro/doc/data/TRADING_SESSION_GENERALIZATION_2026-10-09.md) 与 [专项交接](/Users/kerry/work/bomber1/pro/doc/HANDOFF/gaps/HANDOFF_TRADING_SESSIONS_GENERALIZATION_2026-10-09.md) 已整理交易日历、会话模板、产品／期权系列映射及例外／版本数据要求；真实源表契约与实施仍待推进。

当前 [trading_sessions.py](/Users/kerry/work/bomber1/pro/bomber/framework/trader/runtime/trading_sessions.py) 仍含 CopperSessions、IndexSessions 和 CU／IM 分支，[history/windows.py](/Users/kerry/work/bomber1/pro/bomber/framework/dataprep/history/windows.py) 仍含 ImDayWindow。本专项状态是“需求／数据规范完成，代码未实施”，不改变总体 GAP 的范围和关闭结论。

## 共享跟踪文档中的旧状态残留

- GAP-01 索引已关闭，末尾关闭表及推进建议仍有待首次成交文字。
- GAP-04 的最新实施段已登记 PF0911—0916，部分旧说明仍停留在因子／股指入口未接通阶段。
- GAP-05 索引和基线未充分体现 04 多品种及多静态目标续执行，也未区分 PF0921 通过与 PF0924 部署失败。
- GAP-06 旧描述没有区分普通入口拒绝旧文件与持续模式可恢复的例外。
- GAP-10 旧基线仍有“没有联合入口”描述，与新增实现不符。
- 旧“EMA 暂缓交易”及旧数据源限制不能覆盖当前真实成交和正式来源政策。

这些属于文档状态一致性问题，不是新 GAP，也不是新的通过证据。本次只更新本快照，未覆盖共享清单及专项文档。

## 建议下一步

1. 先解除当前 04 验收阻塞：按 PF0924 全文件核对部署一致性，再跑 cross-section 受影响组；PF0922 entry 若尚未验则补。既有未受影响通过组不重复。通过后取得真实五品种同步帧及最终 Recording summary，再评估组合报单。
2. GAP-02 从根因分析进入统一期限修复，覆盖入口、贡献、实际发送及到期维护；不是只补一个 now_ns 参数。
3. 按已交接的新交易日条件验正式 IM 历史→实时 Recording，并单独推进 GAP-06 的生产交易状态恢复。已通过的指标重启不重复扩大验收范围。
4. GAP-10 按首期边界验双端实际通路与失败恢复；GAP-05 的通用多腿敞口协调、GAP-08 的自定义特征仍分别实施。
5. 正式确定 GAP-09 状态权威和 GAP-11 部署目标；交易会话通用化按独立专项补实际源数据，不混入总体评估。

此顺序兼顾当前验收阻塞与架构依赖，不要求所有工作串行。后续关闭应登记匹配源码版本的实际结果，不能将旧版本通过、启动日志、本地状态快照或仅有修复交付当作整项验收完成。
