"""04 SimNow集中离线验收；记录版本/日志/退出码，首个失败即停止。"""

import argparse
import hashlib
from importlib import import_module
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
FOUR_VENUE_VERSION = "PF2026101208_REV2"
FOUR_VENUE_RUNTIME_HASHES = {
    "bomber/framework/dataprep/live_portfolio.py": "87bfe1d033b4b3efa4338010fbf368a9b262d71987738744da6a82071cf1e48c",
    "bomber/framework/market/stream/ctp/feed.py": "065a4effbabbf281f13c9d64723a2ae6d073bec6d01147894c147e20b081a34b",
    "bomber/framework/market/stream/ctp/converter.py": "157648c40bed2f5467cb9de68ad4ec2c8f971d62ebf10c77bd7f7c052ea7ee7e",
    "bomber/framework/trader/execution/builders.py": "54733c8ab2e7bb9713a2cd2bfcd4d9fe274c53479bc7eac6a8661b9428d2b37d",
    "bomber/framework/trader/execution/ctp/accounting.py": "6bb37ceb2bcad91b4c82f6a6cf77da0440cc8403867a3353f3417106c952f162",
    "bomber/framework/trader/execution/ctp/ledger.py": "97368cdee2e0411ff927e4bdb614e35b705980db5691cdbf488332bde135827e",
    "bomber/framework/trader/execution/ctp/planner.py": "3d119db17d95b85289ba905c1d7f1fa5a3d97d7d54e31fadd5cb7d2189a15f40",
    "bomber/framework/trader/execution/ctp/limit_planner.py": "52490c75d9464c8b2a96bfbcab0da30d1e1f8f2876d7e2421b342545a7d6aec7",
    "bomber/framework/trader/execution/ctp/native_driver.py": "620f3847b53fac28ab85e25805ab961c58ac2e672b78f4b5eebe3f6c85f6f798",
    "bomber/framework/trader/execution/ctp/td_transport.py": "75522647bc5b82226dbc1992e2958d4391f8920b724077062210c1dc42b71eb5",
    "bomber/framework/trader/runtime/ctp_account.py": "a404376dd009fd1f777a61f2683bf35723bf18b884da635aa316e94c2724fc6a",
    "demos/04_cross_section/run_live.py": "a27b235492ed6def166b29c4bc58593229881394df53b89670aa95dc16e96dea",
    "demos/04_cross_section/live_runtime.py": "d4bbad3600d3318faa87c4b708592a3a978d9ca18bc6a14fd568d4958e523bf1",
    "demos/04_cross_section/recovery.py": "c641001e9175fcc9aba5e214dd72eb581aad89bb33dc5e93c6987345b3883ce3",
    "tests/test_cross_section_live.py": "dad0dcaeca3da9a5e57cd4dbef059b4ea26809bab0376177d77d2219c1d5b2bc",
    "tests/test_live_common.py": "718871a1902621f8da124abd8019f70188599a6ee83ef59b5c2041adbb5cd5e5",
}
FEATURE_DEPLOYMENT_GROUPS = frozenset(("feature-datahub", "feature-query-live", "option-vega", "option-vega-live", "option-calendar", "option-shared"))
# 补充原生/08被测文件摘要；入口摘要由独立GAP08入口持有，不在此处自引用。
FEATURE_RUNTIME_HASHES = {
    "bomber/framework/market/stream/ctp/converter.py": "157648c40bed2f5467cb9de68ad4ec2c8f971d62ebf10c77bd7f7c052ea7ee7e",
    "bomber/framework/trader/execution/builders.py": "54733c8ab2e7bb9713a2cd2bfcd4d9fe274c53479bc7eac6a8661b9428d2b37d",
    "bomber/framework/trader/execution/ctp/accounting.py": "6bb37ceb2bcad91b4c82f6a6cf77da0440cc8403867a3353f3417106c952f162",
    "bomber/framework/calendars/DateUtilities/Calendar.pyx": "efcf365e9795bb1669527c3639b21d28d99627119f772ed8a219502c943543eb",
    "bomber/framework/calendars/__init__.py": "c6eb5a3ca194fc16f19f2c8683ee544fe4ca24ad0590f1183a95ff9f63d4bd3d",
    "bomber/framework/calendars/trading.py": "4f64f92382a87e6206df65d97119b52faa756035765e9f3d808f45ba46f9577c",
    "bomber/framework/dataprep/calendar.py": "ad97c156acf7dd915e9727e30110efb1e5826e41f3512051c423b7462771e7ec",
    "bomber/framework/dataprep/live_options.py": "3222662581df4c0729e2eb4a2e077c9d83938ba35b424cb49ad27481943c4f0c",
    "bomber/framework/market/stream/feature_query.py": "450c8865d47b0713e2ff963da2889b8802bd5774049b8e2f8a4e098aa4c76328",
    "bomber/framework/trader/runtime/live/channels/ctp_recovery.py": "b67571a72c4594ff7ca0672980c7e61bc7178da564beb7979f000806c027f3e1",
    "bomber/framework/trader/runtime/live/channels/features.py": "bc3fba69836682cd6cf5d71014c2f99cb6182f6011bb80fcfa5125f667c55288",
    "bomber/framework/trader/runtime/live/readiness.py": "125a27f8b9ad3ede9809fa0865dfac90f44572f7e979f22c1e115db19883e96b",
    "demos/08_option_vega/acceptance.py": "a9f39a99fc55b77711ef814ec4def22d40315c7dea17e5b7418880524a24cf88",
    "demos/08_option_vega/live_runtime.py": "dc48384c853fa431f48760a11e59727ad1dee7846a3973dd415992d3f505edab",
    "demos/08_option_vega/recovery.py": "08705c4a7a0472e2456d28775a6791556997b0e7ec03e9081be950db1d98fe92",
    "demos/08_option_vega/run_live.py": "dc30f7b80bc7a48c11d5591a732d150dc89d8db8366f10598da5fb9ce05526f9",
    "demos/08_option_vega/strategy.py": "4961502b55a163d6e1cbe69d724771ddcc2beab6b5724efc7943251c411c25a6",
    "scripts/integration/options/__init__.py": "be65a34d8f3388d3252d04a55411d216618753783cbba6d4cf40f8aa24690b02",
    "scripts/integration/options/recording.py": "1d0ff5e5b14dd0223640bcfaacd94165ff3077d8e15d5594364ad8d711d39aeb",
    "scripts/integration/reference_data/calendar_export.py": "f6ac57245f7893d0cc7406173f573e466df143fb617de969c95f9c49c9e90555",
    "tests/run_option_vega_offline.py": "02d2a295493a429720bb39f3083fa6c712904640672bf70fc5a9533c9756a52b",
    "tests/test_calendars_compiled.py": "bb410784db982991974947cd52242e6800d46e0eecc55b8f57e1c3316abf3c54",
    "tests/test_index_query_feed.py": "b10ce4d0dff231e61e58c37b36f1a2b7a08615c6bd56c69139837f8544c7fafa",
    "tests/test_live_readiness.py": "68be26427fa88d3821f1aa520c84749756f1793a77c96aad1d0214f19f2a0540",
    "tests/test_live_recovery.py": "3d536ee48fbcc9fda1a91de95d8f65b2350e1fec00ed8eebe5295db8062101c6",
    "tests/test_option_recording_acceptance.py": "393789d6da53972f9f0f04b899144a261a236df5dd801410a1be352268f9d91b",
    "tests/test_option_vega_assembly.py": "33feb49813e7cbc3080e92d4b14279ff80ae3146239fb5cf59d891ef2e4f2dc0",
    "tests/test_option_vega_live.py": "1382d882350796814fe07d5fcfba5a21a11292abbfc1cae66f39ca615c992208",
    "tests/test_trading_calendar.py": "bde86802148881d8fda9aa0020ec2e05c35fbf134fa0bc0f7fa23b9da0991ff4",
    "bomber/framework/market/stream/health.py": "9db27606e1292e9e5a35c23ea2a32de466a0622effd960868e68d6a44353b8d1",
    "bomber/framework/market/stream/ctp/feed.py": "065a4effbabbf281f13c9d64723a2ae6d073bec6d01147894c147e20b081a34b",
    "bomber/framework/dataprep/features/query.py": "3a94d8bc0735e64e60da485a1ea3683438c78946c8f6f2ffcffa4f9ef256523a",
    "tests/test_ctp_depth_health.py": "6ed1585e89550a26d05e79c3cf2438b8f2f497f5499ba1a0b1ad6ce83845bbc4",
    "demos/08_option_vega/replay_test.py": "725692fbf24f300a9c190459672b465924d3a8564a8af1646cf434a583e393fb",
    "tests/test_option_replay_test.py": "e40ee8fc098889e726e9b62c854194fa021bce36e5adbe5817b42221983937bd",
    "demos/08_option_vega/execution_audit.py": "87a3a2723b2342c1942b611eb02bee656c8585c19e5f8ce7d6578856d69818d2",
    "tests/test_option_execution_audit.py": "b1c2e4257a2fdafda2c5682c642fae057e8abbc17fe59131ae087ec603e61442",
    "bomber/framework/market/native/dolphin/driver.py": "5051664e2b5be093431041cedd74de13b0cb87da5962dc04a44e15f8d388bac3",
    "bomber/framework/market/stream/dolphin/config.py": "3acd6a5a052f61adc3744612cf65e1edd3a538937cfc43d92e41943c411161b9",
    "bomber/framework/market/stream/dolphin/converter.py": "e0cd771fca99a01242db9293c7a5b96771825dc7fac1b4ad34f477b30df8da58",
    "bomber/framework/market/stream/dolphin/feed.py": "6601b5c79f756ad863976742fc27a1700edfbe897ceaf411effcb77fb0e1172e",
    "bomber/framework/trader/runtime/live/channels/dolphin.py": "e928b84ba28cd4c9e20defb69d5f584a55e87c2827a75f3f755e869e6d72c626",
    "tests/test_option_dolphin_stream.py": "a8cb1e2306d112b6171fede640cf0e3900ff63c6e03546147c6292c5d6e21edb",
    "scripts/integration/options/dolphin_stream_probe.py": "1b9b7555a0662217347612bcd2b02e61a5632e661c638d7fed14653eb1c407e8",
    'bomber/framework/trader/execution/ctp/limit_planner.py': '52490c75d9464c8b2a96bfbcab0da30d1e1f8f2876d7e2421b342545a7d6aec7',
    'bomber/framework/trader/execution/shared.py': '8c419afe212f762c659ae3d0eb767bbeaf34a158423dfca76f9b34c70e0643bc',
    'bomber/framework/trader/persistence.py': 'f093a42413126d7afd16bb1161604b7011347a11e779f1f2a0196f4b426e4dd6',
    'bomber/framework/trader/runtime/live/channels/ctp_rollover.py': '298dcef3ddcd2df09a2d6219cbeebc3714ba6ab90721704fd0e52009b404789a',
    'bomber/framework/trader/runtime/live/channels/ctp_shared.py': '57e8a3ef24c87b3bd8414919839c2b09c767bf5aa5769b4eb7c47a7fdd88341f',
    'bomber/framework/trader/runtime/live/shared.py': '217563c37070cc24f2084dad14f1daa6d794a6a9740f992ad12f85ea2553168b',
    'demos/08_option_vega/rollover.py': '62953d21fe1d1fe5dd93a34f3c0e9cf334b2c6523a13bf964e3da93401633fa5',
    'scripts/integration/options/shared.py': '72db9fd7a2a17a79c5893d6c3feee404333a1e764e349268c76eb88933010022',
    'scripts/integration/options/simnow_migrate.py': '4f799d8dfc60596ba0d5183ab41339f9bb09c3d9c951e616a295aff09001078d',
    'scripts/integration/options/simnow_preflight.py': '5028abd4b2528845762b0896bcbb312d3c40daf212f1293d1f01d5d169a39635',
    'scripts/integration/shared_account/config.py': '91ddc9c40168e259657f054f935989380cf4d0e59576c23813cd2dbb748d3ffc',
    'scripts/integration/shared_account/factories.py': '23f6a1677fead49cf2a7ed903891daa41fc203a2f760a66bbcad9f187b56f694',
    'scripts/integration/shared_account/preflight.py': 'ecbb8b93e6a7956f88c72d5bd639075d5c0f6bc6e895c10e8d36a22ea0cdf89b',
    'scripts/integration/shared_account/rollover.py': '087e2ad90d2f46f55ef6cc156609d919f4b53bfd2baa20827cf893133718df85',
    'scripts/integration/shared_account/run.py': '928a75cf8fdda45feca7a599eb8c02291cd3500cda3ebcfe9aa4730c9b08e3e2',
    'scripts/integration/shared_account/server.py': '2a9de6f1f89be23a52a340394a1be0cc2f9b4e02d7d1dbf5bc3642fd19d431ab',
    'scripts/integration/shared_account/worker.py': '9ae2098f8a497b4a2058292b4cafc3126f23425d188be4813a67dba72a29139e',
    'tests/test_option_shared_rollover.py': '35c8759e939081161713621b127190adfa981c7693491b6acb607670040353f9',
    'tests/test_option_simnow_migrate.py': 'a7256b74943c985ec50239b80a804778b9b45e6e78454b0863b551d8c4ff0f72',
    'tests/test_option_simnow_preflight.py': 'cfc761c53c0a7082528272d660e636ff2100d70b2f13667fa282a4e4636ff8bd',
    'bomber/framework/trader/runtime/live/continuous.py': '9954bd03b3f79067bd112d186170375a37294deb4106188845d2a6ae6bcab627',
    'scripts/integration/shared_account/continuous.py': 'aa9c076ec4e24319490dac0ed4af6adba52119431a32bea94943ad58d0b6a18a',
    'tests/test_continuous_position_runtime.py': 'f8d107d205d5387b0b8aac958aaf181fdc22dfa0559aed6c991ce1df7ae56b17',
    'tests/test_shared_continuous.py': 'c6e688611bc984707fa8fd095acedb2f6f4a68bac6326925814380c1b33470e7',
    'bomber/framework/dataprep/session_inputs.py': '9632a472e6621418eb00f03872baf4635a7d3f51349f2c3045d1e189077f6ede',
    'bomber/framework/calendars/sessions.py': '3ae1627d66f50a44a3ea53bb9e953b2e981b3e3a947ef36fbc18704199fb540f',
    'bomber/framework/calendars/hours.py': '273d4ab3bb0da4dd28fc805d4bc8c50790b328309461a7ee36383dc935facda7',
}


def inspect_feature_deployment(root, expected, retired=()):
    """只读代码/配置字节；先识别混版，不导入原生组件或待测Demo。"""
    sources = {relative: hashlib.sha256((root / relative).read_bytes()).hexdigest()
        if (root / relative).is_file() else None for relative in expected}
    return {"sources": sources,
        "mismatches": [{"path": relative, "expected": digest, "actual": sources[relative]}
            for relative, digest in expected.items() if sources[relative] != digest],
        "retired_files": [relative for relative in retired if (root / relative).exists()]}


CASES = {
    "feature-datahub": ("tests.run_feature_datahub",),
    "feature-query-live": ("unittest", "tests.test_index_query_feed"),
    "option-vega": ("unittest", "tests.test_demo_option_vega", "tests.test_option_vega_live"),
    "option-vega-live": ("unittest", "tests.test_option_vega_assembly", "tests.test_option_replay_test", "tests.test_option_execution_audit", "tests.test_option_dolphin_stream", "tests.test_option_recording_acceptance"),
    "option-shared": ("unittest", "tests.test_option_shared_rollover", "tests.test_option_simnow_migrate", "tests.test_option_simnow_preflight", "tests.test_continuous_position_runtime", "tests.test_shared_continuous"),
    "option-calendar": ("unittest", "tests.test_calendars_compiled", "tests.test_trading_calendar", "tests.test_option_recording_acceptance"),
    "execution-composition": ("tests.test_execution_composition",),
    "shared-account": ("tests.test_shared_account",),
    "ema-recovery": ("tests.test_main_ema_recovery",),
    "continuous": ("tests.test_main_ema_continuous",),
    "live-common": ("unittest", "tests.test_live_common", "tests.test_live_channels", "tests.test_live_recovery", "tests.test_execution_composition", "tests.test_live_readiness", "tests.test_ctp_depth_health"),
    "cross-section": ("tests.test_cross_section_live",),
    "signal": ("tests.test_demo_cross_section_signal",),
    "entry": ("tests.run_main_ema_live",),
    "routing": ("tests.run_main_ema_simnow", "--stage", "routing"),
    "ctp": ("tests.run_main_ema_simnow", "--stage", "ctp"),
    "assembly": ("tests.test_strategy_assembly",),
    "dispatch": ("tests.run_execution_dispatch",),
    "attribution": ("tests.test_position_attribution",),
    "ctp-autosave": ("tests.run_p4_ctp_autosave",),
    "ctp-recovery": ("tests.run_p4_ctp_recovery",),
    "ctp-driver": ("tests.run_p4_ctp_driver",),
}
SOURCES = (
    "bomber/framework/datahub/features/schema.py",
    "bomber/framework/dataprep/features/raw.py",
    "bomber/framework/dataprep/features/definition.py",
    "bomber/framework/dataprep/features/query.py",
    "bomber/framework/dataprep/features/configs/features.json",
    "bomber/framework/dataprep/features/configs/features.example.json",
    "tests/test_feature_definitions.py",
    "bomber/framework/dataprep/features/dolphin_query.py",
    "bomber/framework/market/stream/feature_query.py",
    "bomber/framework/trader/runtime/live/channels/features.py",
    "tests/test_dolphindb_index_features.py",
    "tests/test_index_query_feed.py",
    "scripts/integration/features/index_readonly.py",
    "scripts/integration/features/read_only.py",
    "bomber/framework/datahub/features/contracts.py",
    "bomber/framework/datahub/features/store.py",
    "bomber/framework/datahub/features/alignment.py",
    "bomber/framework/datahub/features/frames.py",
    "bomber/framework/datahub/features/replay.py",
    "bomber/framework/datahub/features/__init__.py",
    "bomber/framework/dataprep/features/base.py",
    "bomber/framework/dataprep/features/codec.py",
    "bomber/framework/dataprep/features/file.py",
    "bomber/framework/dataprep/features/database.py",
    "bomber/framework/dataprep/features/factory.py",
    "bomber/framework/dataprep/features/service.py",
    "bomber/framework/dataprep/features/samples.py",
    "bomber/framework/dataprep/features/__init__.py",
    "bomber/framework/datahub/temporal.py",
    "bomber/framework/datahub/__init__.py",
    "bomber/framework/dataprep/sources/policy.py",
    "tests/run_feature_datahub.py",
    "tests/test_feature_datahub.py",
    "demos/08_option_vega/assembly.py",
    "demos/08_option_vega/strategy.py",
    "demos/08_option_vega/vega_signal.py",
    "demos/08_option_vega/run_backtest.py",
    "demos/08_option_vega/run_live.py",
    "demos/08_option_vega/live_runtime.py",
    "demos/08_option_vega/recovery.py",
    "demos/08_option_vega/checkpoint.py",
    "bomber/framework/market/frames.py",
    "bomber/framework/market/stream/aggregation.py",
    "bomber/framework/dataprep/live_options.py",
    "bomber/framework/dataprep/metadata.py",
    "bomber/framework/trader/runner.py",
    "bomber/framework/trader/execution/ctp/planner.py",
    "bomber/framework/trader/execution/ctp/limit_planner.py",
    "bomber/framework/trader/execution/ctp/accounting.py",
    "bomber/framework/trader/execution/builders.py",
    "bomber/framework/trader/runtime/live/channels/dolphin.py",
    "tests/test_option_vega_live.py",
    "tests/test_option_vega_assembly.py",
    "tests/run_option_vega_offline.py",
    "bomber/framework/trader/execution/policy.py",
    "bomber/framework/trader/execution/fanout.py",
    "bomber/framework/trader/execution/account.py",
    "bomber/framework/trader/execution/shared.py",
    "bomber/framework/trader/runtime/live/shared.py",
    "bomber/framework/trader/runtime/live/channels/ctp_shared.py",
    "scripts/integration/shared_account/config.py",
    "scripts/integration/shared_account/factories.py",
    "scripts/integration/shared_account/run.py",
    "tests/test_shared_account.py",
    "bomber/framework/trader/execution/model.py",
    "bomber/framework/trader/execution/__init__.py",
    "bomber/framework/trader/runtime/live/local.py",
    "bomber/framework/trader/runtime/live/channels/ctp_market.py",
    "tests/test_execution_composition.py",
    "bomber/framework/trader/template.py",
    "bomber/framework/trader/portfolio.py",
    "bomber/framework/trader/execution/planner.py",
    "bomber/framework/trader/runtime/live/recovery.py",
    "bomber/framework/trader/runtime/live/channels/ctp_recovery.py",
    "demos/01_main_ema/recovery.py",
    "tests/test_live_recovery.py",
    "tests/test_main_ema_recovery.py",
    "scripts/integration/ctp_binance/run.py",
    "bomber/framework/trader/runtime/__init__.py",
    "bomber/framework/trader/runtime/direct.py",
    "bomber/framework/trader/runtime/live/__init__.py",
    "bomber/framework/trader/runtime/live/channels/__init__.py",
    "bomber/framework/trader/runtime/live/channels/binance.py",
    "bomber/framework/trader/runtime/live/channels/ctp.py",
    "bomber/framework/trader/runtime/live/contracts.py",
    "bomber/framework/trader/runtime/live/health.py",
    "bomber/framework/trader/runtime/live/profiles.py",
    "bomber/framework/trader/runtime/live/runtime.py",
    "tests/test_live_channels.py",

    "bomber/framework/trader/runtime/live_policy.py",
    "bomber/framework/trader/runtime/ctp_setup.py",
    "bomber/framework/trader/runtime/ctp_account.py",
    "bomber/framework/dataprep/live_cache.py",
    "bomber/framework/dataprep/live_cached_role.py",
    "bomber/framework/dataprep/live_portfolio.py",
    "bomber/framework/trader/live_roles.py",
    "bomber/framework/market/stream/aggregation.py",
    "tests/test_live_common.py",
    "demos/01_main_ema/continuous.py",
    "demos/01_main_ema/checkpoint.py",
    "scripts/integration/reference_data/configs/session_overrides_cu_2026.csv",
    "bomber/framework/trader/runtime/trading_sessions.py",
    "tests/test_main_ema_continuous.py",
    "bomber/framework/market/basic/base.py",

    "bomber/framework/market/stream/ctp/feed.py",
    "bomber/framework/market/stream/ctp/converter.py",
    "bomber/framework/trader/runner.py", "bomber/framework/trader/execution/builders.py",
    "bomber/framework/trader/execution/ctp/limit_planner.py",
    "bomber/framework/trader/runtime/ctp.py", "bomber/framework/trader/runtime/managed.py",
    "bomber/framework/trader/persistence.py", "bomber/framework/trader/assembly.py",
    "bomber/framework/dataprep/live_references.py", "bomber/framework/dataprep/live_role.py",
    "bomber/framework/trader/execution/ctp/native_driver.py",
    "bomber/framework/trader/execution/ctp/td_transport.py",
    "bomber/framework/trader/execution/attribution.py",
    "bomber/framework/trader/execution/live/client.py",
    "bomber/framework/trader/execution/live/controlled.py",
    "demos/04_cross_section/run_live.py", "demos/04_cross_section/live_runtime.py",
    "demos/04_cross_section/recovery.py",
    "demos/04_cross_section/strategy.py", "demos/04_cross_section/cross_section_signal.py",
    "demos/01_main_ema/run_live.py", "demos/01_main_ema/strategy.py",
    "tests/test_cross_section_live.py", "tests/run_main_ema_live.py",
    "tests/run_p4_ctp_td_transport.py", "tests/test_demo_cross_section_signal.py",
    "tests/run_cross_section_acceptance.py", "tests/run_main_ema_simnow.py",
    "tests/test_strategy_assembly.py", "tests/run_execution_dispatch.py",
    "tests/test_position_attribution.py",
    "tests/run_p4_ctp_autosave.py", "tests/run_p4_ctp_recovery.py", "tests/run_p4_ctp_driver.py",
    "bomber/framework/market/native/dolphin/driver.py",
    "bomber/framework/market/stream/dolphin/config.py",
    "bomber/framework/market/stream/dolphin/converter.py",
    "bomber/framework/market/stream/dolphin/feed.py",
    "tests/test_option_dolphin_stream.py",
    "scripts/integration/options/dolphin_stream_probe.py",
)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--only", choices=tuple(CASES), action="append")
    parser.add_argument("--timeout", type=float, default=180)
    parser.add_argument("--report-dir", type=Path, default=ROOT / "tests/results")
    args = parser.parse_args(argv)
    if args.timeout <= 0:
        parser.error("timeout须为正")
    path = args.report_dir / f"cross-section-acceptance-{time.time_ns()}"
    path.mkdir(parents=True, exist_ok=False)
    report = {"python": sys.executable, "project": str(ROOT), "status": "running", "modules": [], "sources": {}}
    print(f"离线验收 Python={sys.executable} project={ROOT} report={path}", flush=True)
    try:
        if not args.only or "cross-section" in args.only:
            check = inspect_feature_deployment(ROOT, FOUR_VENUE_RUNTIME_HASHES)
            report["cross_section_deployment"] = {"version": FOUR_VENUE_VERSION, **check}
            report["sources"].update(check["sources"])
            for mismatch in check["mismatches"]:
                print(f"四交易所版本不一致: {mismatch['path']} expected={mismatch['expected']} "
                      f"actual={mismatch['actual']}", flush=True)
            if check["mismatches"]:
                raise RuntimeError("04四交易所交付版本不一致；先同步所列源码，再复测")
        if not args.only or FEATURE_DEPLOYMENT_GROUPS.intersection(args.only):
            from tests.run_feature_datahub import EXPECTED_SOURCE_HASHES, RETIRED_SOURCES, ACCEPTANCE_VERSION
            check = inspect_feature_deployment(ROOT, {**EXPECTED_SOURCE_HASHES, **FEATURE_RUNTIME_HASHES}, RETIRED_SOURCES)
            report["feature_deployment"] = {"version": ACCEPTANCE_VERSION, **check}
            report["sources"].update(check["sources"])
            for mismatch in check["mismatches"]:
                print(f"版本不一致: {mismatch['path']} expected={mismatch['expected']} actual={mismatch['actual']}", flush=True)
            if check["retired_files"]:
                print("须移除退役代码: " + ", ".join(check["retired_files"]), flush=True)
            if check["mismatches"] or check["retired_files"]:
                raise RuntimeError("特征/08交付版本不一致；先同步所列源码/配置及清理旧文件，再复测")
        for relative in SOURCES:
            if relative not in report["sources"]:
                source = ROOT / relative
                report["sources"][relative] = hashlib.sha256(source.read_bytes()).hexdigest() if source.is_file() else None
        for name in ("bomber.framework.trader.execution.builders", "bomber.framework.trader.runner",
                     "demos.04_cross_section.run_live", "demos.04_cross_section.strategy"):
            module = import_module(name)
            actual = Path(module.__file__).resolve()
            if not actual.is_relative_to(ROOT):
                raise RuntimeError(f"模块未加载本次项目源码: {name} {actual}")
            print(f"加载路径: {name}={actual} SHA256={hashlib.sha256(actual.read_bytes()).hexdigest()}", flush=True)
        entry = import_module("demos.04_cross_section.run_live")
        runtime = import_module("demos.04_cross_section.live_runtime")
        feed = import_module("bomber.framework.market.stream.ctp.feed")
        recovery = import_module("demos.04_cross_section.recovery")
        common_recovery = import_module("bomber.framework.trader.runtime.live.channels.ctp_recovery")
        if not issubclass(recovery.ResumeLifecycle, common_recovery.CtpResumeLifecycle):
            raise RuntimeError("部署版本不一致：04/recovery.py仍为旧恢复流程；同步"
                "doc/evidence/checksums/PF2026101037_REV2_SHA256.txt所列文件并核对摘要后再测试")
        expected_interfaces = (
            (entry, "parse_args", "04 run_live.parse_args"),
            (runtime.CrossSectionSessionRunner, "bar_is_current", "04 runner.bar_is_current"),
            (feed.CtpLiveDataFeed, "depth_observations", "CTP feed.depth_observations"),
        )
        for owner, attribute, label in expected_interfaces:
            if not hasattr(owner, attribute):
                raise RuntimeError(f"部署文件版本不一致，缺少{label}；同步PF2026100924清单全部文件并核对SHA后再测试")
    except Exception as error:
        report.update(status="failed", deployment_error=str(error))
        (path / "summary.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
        print(f"部署/加载核对失败: {error}", flush=True)
        return 2
    for key, command in CASES.items():
        if args.only and key not in args.only:
            continue
        started = time.monotonic()
        try:
            completed = subprocess.run([sys.executable, "-u", "-m", *command], cwd=ROOT,
                timeout=args.timeout, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
            code, output = completed.returncode, completed.stdout
        except subprocess.TimeoutExpired as error:
            raw = error.stdout or ""
            output = (raw.decode(errors="replace") if isinstance(raw, bytes) else raw) + "\n模块超时\n"
            code = 124
        (path / f"{key}.log").write_text(output, encoding="utf-8")
        print(output, end="" if output.endswith("\n") else "\n", flush=True)
        row = {"module": key, "exit_code": code, "seconds": round(time.monotonic() - started, 3)}
        report["modules"].append(row)
        report["status"] = "failed" if code else "running"
        (path / "summary.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
        print(f"模块结果: {row}", flush=True)
        if code:
            print(f"停止，仅复测失败组: python -u -m tests.run_cross_section_acceptance --only {key}", flush=True)
            return 1
    report["status"] = "passed"
    (path / "summary.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    print("全部选定离线模块通过；实际柜台Recording/组合成交仍须独立验收。", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
