# DataHub参考数据

现有角色、因子、研究价格、目标计划及时间接口保持原结构。DataHub不加载或推送真实Bar/Tick，也不接管撮合、订单、仓位、Greeks或交易信号。分钟行情读取仍由market/replay和回测入口负责。

本次只增加 `option_basic.py` 的期权条款与Provider，沿用已有 `ReferenceRecord → InMemoryAsOfProvider → DataHub` 时间契约。详细架构仍见 `doc/DATAHUB_MINIMAL_CORE.md`。

## 期权基本信息

不可变 `OptionBasic` 支持：代码、交易所、币种、标的、认购/认沽、行权价、乘数、上市日、最后交易日、到期日，以及可选tick和行权方式。没有tick时返回None，不硬编码；合约代码和交易所标识原样保留，不擅自映射MO到IM。

`OptionBasic.from_mapping()` 接受 `Code/exchangeCD/currencyCD/varTicker/contractType/strikePrice/contMultNum/listDate/lastTradeDate/expDate` 等源字段，也接受标准字段。认购支持CO/C/CALL/认购，认沽支持PO/P/PUT/认沽。合约类型独立于代码命名，不限制其他期权交易所的命名规范。

```python
from datahub import OptionBasicProvider, ReferenceRecord, DataHub, AsOfQuery

# 文件格式适配器只读opt_basic，核心仍不依赖pandas。
# 必须提供已经核实的时间规则；不要把date自动视为发布时间。
def record_factory(info, source_row):
    return ReferenceRecord(
        dataset="option_basic", key=info.symbol, value=info,
        event_ns=int(source_row["effective_ns"]),
        available_ns=int(source_row["available_ns"]),
        source_ns=int(source_row["source_ns"]),
    )

provider = OptionBasicProvider.from_feather(
    "/workspace/data/temp_bomber1/ctp/role/opt_basic.feather",
    record_factory=record_factory,
)
hub = DataHub({"option_basic": provider})
# query沿用已有AsOfQuery，时间戳为调用方当前决策纳秒。
# info = provider.basic_at("MO2609-C-6400", query)
# info = hub.get("option_basic", "MO2609-C-6400", query)[-1].value
```

上例中的三个时间列不是自动生成的：当前源表若只有date，必须确认date含义，并由回测入口/适配器通过外部发布时间日程构造record_factory。支持显式日终策略DAY_END及source_trading_day，沿用现有交易日隔离。不会凭自然日推导下一交易日，也不会默认将最终快照回灌历史。已到期合约的基本信息仍可查询，交易生命周期判断由使用方负责。

角色文件名 `fut_contract.feather` 等仍由原来的回测资料加载代码处理；本次不新建目录管理层，也不改它们的原有解析逻辑。

## 验证

`python -m unittest tests.test_datahub_option_basic`（Feather用例需要pandas、pyarrow）。原有回归：`python -m tests.run_datahub`、`python -m tests.run_role_research`。

已修正原有RolePriceStore在同一合约/时间戳出现冲突价格时按输入顺序选择价格的问题：冲突显式拒绝，完全相同的重复记录合并。
